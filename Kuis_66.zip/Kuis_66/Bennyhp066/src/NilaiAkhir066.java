import java.util.Scanner;

class NilaiAkhir066 {
    public static void main(String[] args) {
    Scanner input = new Scanner (System.in);
    char grade ;
    final double n_tugas , n_uts , n_kuis , n_uas , n_akhir;

    System.out.print("Nilai tugas : ");
    n_tugas = input.nextDouble();
    
    System.out.print("Nilai kuis : ");
    n_kuis = input.nextDouble();

    System.out.print("Nilai uts : ");
    n_uts = input.nextDouble();
    
    System.out.print("Nilai uas : ");
    n_uas = input.nextDouble();

    n_akhir = (0.15 * n_tugas + 0.20 * n_kuis + 0.30 * n_uts + 0.35 * n_uas);

    if (n_akhir >= 81 && n_akhir <=100){
        grade = 'A';
    }
    else if (n_akhir > 61 && n_akhir < 80){
        grade = 'B';
    }
    else if (n_akhir > 41 && n_akhir < 60){
        grade = 'C';
    }
    else if (n_akhir > 21 && n_akhir < 40){
        grade = 'D';
    }
    else {
        grade = 'E';
    }

    System.out.println("Nilai Akhir : " + n_akhir);
    System.out.println("Nilai Huruf : " + grade);
    }
    
}
