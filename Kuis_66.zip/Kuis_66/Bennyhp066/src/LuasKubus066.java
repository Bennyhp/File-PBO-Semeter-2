import java.util.Scanner;

public class LuasKubus066 {
    public static void main (String[]args) {

    Scanner input = new Scanner(System.in);

    System.out.println("Masukkan Nilai Sisi : ");

    int sisi = input.nextInt();

    int luas = 6 *(sisi*sisi);

    System.out.println("Luas kubus adalah : "+ luas);
    }
}