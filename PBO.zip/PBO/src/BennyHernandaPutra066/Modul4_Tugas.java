package BennyHernandaPutra066;


public class Modul4_Tugas  {
    private int [][] data1,data2,hasil1;
    private double [][] data;
    private double hasil2;
    
    public void setData1(int[][] data1){
        this.data1 = data1;
        data1 = null;
    }
    
    public int[][] getData1(){
        return data1;
    }
    
    public void setData2(int[][] data2){
        this.data2 = data2;
        data2 = null;
    }
    
    public int[][] getData2(){
        return data2;
    }
    
    public void setPenjumlahan(int[][] data1,int[][]data2){
        hasil1 = data1;
        for (int i = 0; i < data1.length; i++) {
            for (int j = 0; j < data1[i].length; j++) {
                hasil1[i][j] = data1[i][j]+data2[i][j];
                System.out.print(hasil1[i][j]+"  ");
            }
            System.out.println();
        }
        data1 = null;
        data2 = null;
    }
    
    public int[][] getPenjumlahan(){
        return hasil1;
    }
    
    public void setPengali(int[][] data, double a){
        for (int i = 0; i < data.length; i++) {
            int[] row = new int[data[i].length];
            for (int j = 0; j < data[i].length; j++) {
                hasil2 =  data[i][j]*a;
                System.out.print(hasil2+" ");
            }
            System.out.println();
        }
        data = null;
    }
    
    public double getPengali(){
        return hasil2;
    }
    
    public void tampil(String a){
        System.out.println(a);
        a = null;
    }
    
    public void tampil(String data1[][],String data2[][]){
        for (int i = 0; i < data1.length; i++) {
            for (int j = 0; j < data1[i].length; j++) {
                System.out.println(data1[i][j]+"");
                System.out.println(data2[i][j]+"");
            }
            System.out.println();
        }
        data1 = null;
        data2 = null;
    }
    
    public void tampil(int data1[][]){
        for (int i = 0; i < data1.length; i++) {
            for (int j = 0; j < data1[i].length; j++) {
                System.out.print(data1[i][j]+"  ");
            }
            System.out.println();
        }
        data1 = null;
    }
    
    public void tampil2(int data2[][]){
        for (int i = 0; i < data2.length; i++) {
            for (int j = 0; j < data2[i].length; j++) {
                System.out.print(data2[i][j]+"  ");
            }
            System.out.println();
        }
        data2 = null;
    }
    
    public void tampil(double a){
        System.out.println(a);
    }
    
    public void tampil(double data[][]){
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                System.out.println(data[i][j]+"");
                
            }
            System.out.println();
        }
        data = null;
    }
    
    public void hapus(){
        data1 = null;
        data = null;
        data2 = null;
        hasil1 = null;
        hasil2 = 0;
    }
}

