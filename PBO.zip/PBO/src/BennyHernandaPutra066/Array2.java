package BennyHernandaPutra066;

public class Array2 {
}
class PercobaanArray2 {
    private String[][] Mahasiswa;
    private int [][] data,hasil;
    
    public void setMahasiswa(String[][] Mahasiswa){
        this.Mahasiswa = Mahasiswa;
        Mahasiswa = null;
    }
    
    public String[][] getMahasiswa(){
        return Mahasiswa;
    }
    
    public void setData(int[][] data){
        this.data = data;
        data = null;
    }
    
    public int[][] getData(){
        return data;
    }
    
    public void setPerkalianSkalar(int[][] data, int a){
        hasil = data;
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                hasil[i][j] = a*data[i][j];
            }
            System.out.println();
        }
        data = null;
    }
    
    public int[][] PerkalianSkalar(){
        return hasil;
    }
    
    public void tampil(String a){
        System.out.println(a);
        a = null;
    }
    
    public void tampil(String data[][]){
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                System.out.println(data[i][j]+"      ");
            }
            System.out.println();
        }
        data = null;
    }
    
    public void tampil(int data[][]){
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                System.out.println(data[i][j]+"      ");
            }
            System.out.println();
        }
        data = null;
    }
    
    public void hapus(){
        Mahasiswa = null;
        data = null;
        hasil = null;
    }

}

