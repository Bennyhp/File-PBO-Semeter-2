package BennyHernandaPutra066;

public class MainLatihan1 {

    public static void main(String[] args) {
        Modul3_ArrayLatihan1 ob = new Modul3_ArrayLatihan1();
        int nilai[] = {-5, -3, -6, -3, -4};
        ob.setRataRata(nilai);
        ob.setMaxMin(nilai);
        ob.setMencariIndex(nilai);
    }
    
}
