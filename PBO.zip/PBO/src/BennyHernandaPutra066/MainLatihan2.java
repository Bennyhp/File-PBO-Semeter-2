package BennyHernandaPutra066;


public class MainLatihan2 {

    public static void main(String[] args) {
        Modul3_ArrayLatihan2 ob = new Modul3_ArrayLatihan2();
        int bilangan[] = {2,5,3,5,9,5};
        ob.tampil("Latihan 2 Array Modul 3 ");
        ob.tampil ("                           ");
        ob.tampil("Nilai Array : ");
        ob.setBilangan(bilangan);
        ob.tampil(ob.getBilangan());
        ob.tampil ("                           ");
        ob.tampil("Mengubah Angka 5 Menjadi 1");
        ob.setGanti(bilangan);
        ob.tampil(ob.getBilangan());
        ob.tampil ("                           ");
        ob.tampil("Dikali dengan 0.5");
        ob.setKali(bilangan, 0.5);
        
        ob.hapus();
        bilangan = null;
    }
}

