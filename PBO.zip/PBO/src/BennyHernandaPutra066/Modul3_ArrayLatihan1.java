package BennyHernandaPutra066;

public class Modul3_ArrayLatihan1 {
    
    private int[] nilai;
    private int hasilratarata;
    private int nilaiX;
    boolean benar = false;

    public void setNilai(int[] nilai) {
        this.nilai = nilai;
        nilai = null;
    }
    
    public int[] getNilai() {
        return nilai;
    }

    public void setRataRata(int[] nilai) {
        hasilratarata = 0;
        for (int i = 0; i < nilai.length; i++) {
            hasilratarata = hasilratarata + nilai[i];
        }
        int rataRata = hasilratarata / nilai.length;
        System.out.println("Nilai Rata-rata : " + rataRata);
    }
    
    public void setMaxMin(int[] nilai) {
        int max = nilai[0];
        int min = nilai[0];
        for (int i = 0; i < nilai.length; i++) {
            if (nilai[i] > max) {
                max = nilai[i];
            } else if(nilai[i] < min) {
                min = nilai[i];
            }
        }
        System.out.println("Nilai Max : " + max);
        System.out.println("Nilai Min : " + min);
    }

    public void setMencariIndex(int[] nilai) {
        nilaiX = -3;
        for (int i = 0; i < nilai.length; i++) {
            if (nilai[i] == nilaiX) {
                System.out.println("Data Ditemukan Di Index ke : " + i);
                benar = true; 
            }
        }
    }
}

