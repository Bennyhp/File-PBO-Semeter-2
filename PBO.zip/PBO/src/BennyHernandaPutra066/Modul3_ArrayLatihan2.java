package BennyHernandaPutra066;

public class Modul3_ArrayLatihan2 {

    private int[] bilangan;
    private int ganti;
    private double kali;
    
    
    public void setBilangan(int[] bilangan){
        this.bilangan = bilangan;
        bilangan = null;
    }
    
    public int[] getBilangan(){
        return bilangan;
    }
    public void setGanti(int[] bilangan){
        for (int i = 0; i < bilangan.length; i++) {
            if (bilangan[i] == 5) {
                bilangan[i] = 1;
            }
            
        }
        bilangan = null;
    }
    
    public int getGanti(){
        return ganti;
    }
    
    public void setKali(int[] bilangan,double a){
        for (int i = 0; i < bilangan.length; i++) {
        kali = (double) (bilangan[i]*a);
        System.out.print(kali+", ");
    }
        System.out.println();
    }
    
    public double getKali(){
        return kali;
    }
    
    public void tampil(double a){
        System.out.println(a);
    }
    
    public void tampil(int a){
        System.out.println(a);
    }
    
    public void tampil(String a){
        System.out.println(a);
    }
    
    public void tampil(int a[]){
        String data = "";
        for (int i = 0; i < a.length; i++) {
            if (i==0) {
                data += a[i];
            } else {
                data += ", "+a[i];
            }
        }
        System.out.println(data);
        a = null;
        data = null;
    }
    
    public void hapus(){
        bilangan = null;
        ganti = 0;
        kali = 0;
    }

}
    
