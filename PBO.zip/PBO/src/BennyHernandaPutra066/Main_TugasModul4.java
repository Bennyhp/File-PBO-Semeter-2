package BennyHernandaPutra066;

public class Main_TugasModul4 {
    public static void main(String[] args){
        Modul4_Tugas ob = new Modul4_Tugas();
        int [][] data1 = {
            {1,2},
            {3,5},
            {6,7}
        };
        
        int [][] data2 = {
            {8, 9},  
            {10,11},  
            {12,13}  
        };
    double pengali = 0.5;
    ob.tampil("Kolom A : ");
    ob.setData1(data1);
    ob.tampil(data1);
    ob.tampil("Kolom B : ");
    ob.setData2(data2);
    ob.tampil2(data2);
    ob.tampil("Kolom C : Hasil Penjumlahan :");
    ob.setPenjumlahan(data1, data2);
    ob.tampil("Kolom D : kolom C * dengan 0.5");
    ob.setPengali(ob.getPenjumlahan(), pengali);       
}
}

