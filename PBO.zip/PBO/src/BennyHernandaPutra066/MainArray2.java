package BennyHernandaPutra066;

public class MainArray2 {
    public static void main(String[] args){
        PercobaanArray2 ob = new PercobaanArray2();
        String [][] Mhs = {
            {"NIM","Nama"},
            {"17650123","David"},
            {"17650124","Ahmad"},
            {"17650125","Ratih"},
            {"17650126","Dina"}
        };
        ob.tampil("Data Mahasiswa : ");
        ob.setMahasiswa(Mhs);
        ob.tampil(ob.getMahasiswa());
        ob.tampil("================");
        int[][] data = {
            {1,2},
            {3,4},
            {5,6}
        };
        
        int pengali = 2;
        ob.tampil("Data Matriks : ");
        ob.setData(data);
        ob.tampil(ob.getData());
        ob.tampil("Data Matrix X "+pengali+"   : ");
        ob.setPerkalianSkalar(data, pengali);
        ob.tampil(ob.PerkalianSkalar());

        ob.hapus();
        Mhs = null;
        data = null;
        ob = null;
    }
}
